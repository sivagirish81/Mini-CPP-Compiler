﻿Section : E


Project Title: Mini C++ Compiler


Team Members: R Siva Girish(PES1201700159) , Parshva B Jain(PES1201701336) , Mayank Agarwal(PES1201701349) 


Project Guide : Suhas G.K


Project Abstract: A c++ compiler built using C (lex - yacc) that provides us with the symbol table,Abstract - Syntax tree ,Intermediate code as well as the assembly code generated.


Code Execution : All the code for respecive phases of the evaluation can be executed by running the run shel script.
Steps : ./run.sh
		./a.out < input_file_name


Assembly_code_gen : python Assembly_code_gen.py


Folder Description

+ Phase_1
	+ Lexical analyser to get all tokens
	+ Definition of Grammar

+ Phase_2
	+ Symbol Table

+ Phase_3
	+ Abstract Syntax Tree

+ Phase_4
	+ Intermediate Code Generation
	+ Optimization
	+ Assembly code generation