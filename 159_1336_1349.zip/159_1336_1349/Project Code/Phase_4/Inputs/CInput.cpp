int main()
{
    int a = 10;
    int b = 20;
    int c = 30;
    int d = a + b * c;
    int e = d * b;
}