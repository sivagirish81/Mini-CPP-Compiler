int main()
{
    while (b<4)
    {		
        a = b + c;
        while(e < 5)
        {
            g += 1;
        }
        e = g;
    }
}