int main()
{
    if(a < b)
    {
        int a = 4;
        int b = 6;
        a = b;
	}
    else if(b > a)
    {
        b = 2 + 3;
    }
    else
    {
        int a = 4;
    }
}