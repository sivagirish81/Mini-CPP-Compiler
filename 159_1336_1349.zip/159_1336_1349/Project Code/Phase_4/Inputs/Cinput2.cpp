
int main()
{
    int i = 0;
    int j = 5;
    int k = 7;
    int t = i * j / k;
    int p = t % 2;
}