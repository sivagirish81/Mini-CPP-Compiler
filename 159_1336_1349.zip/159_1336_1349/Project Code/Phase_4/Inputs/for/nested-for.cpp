int main()
{
    int a = 4;
    for(int i = 1; i < 10; i = i + 1)
    {
        int b = 6;
        for(int j = 2; j < 4; j = j + 2)
        {
            int c = 4;
        }
    }
}