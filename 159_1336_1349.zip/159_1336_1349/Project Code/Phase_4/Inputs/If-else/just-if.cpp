//demonstrates symbol table, valuation of syntax, ast, ICG.
//to demonstrate error change int a = 4 to int a 4.
int main()
{
    int a = 4;
    if(a < 5)
    {
        long b = 6;
    }
}