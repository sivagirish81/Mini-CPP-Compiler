
int main()
{
    int a = 4;
    int c = 5;
    if(a < 5)
    {
        if(a < 3)
        {
            int e = 5;
        }
        long b = 6;
    }
    else if(c < 5)
    {
        long d = 4;
    }
}