int main()
{
    int a = 4;
    while(a < 4)
    {
        int b = 6;
        while(b < 6)
        {
            int c = 4;
        }
    }
}