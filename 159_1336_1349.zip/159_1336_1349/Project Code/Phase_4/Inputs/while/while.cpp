int main()
{
    int a = 4;
    while(a < 4)
    {
        int b = 6;
    }
}