int main()
{
    int a = 4;
    for(int i = 1; i < 10; i = i + 1)
    {
        int b = 6;
        while(b < 7)
        {
            int c = 7;
            if(c == 6)
                long d = 4*8;
        }
    }
}