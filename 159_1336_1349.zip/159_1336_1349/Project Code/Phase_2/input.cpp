int main()
{

    int c = 2;
    int i = 0;

    for (i = 5;i < 10;i = i + 1)
    {
        c = 10;
    }
    
}
