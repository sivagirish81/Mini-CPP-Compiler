lex lex.l
gcc lex.yy.c