int main()
{
    int a = 4;
    // int a = c;
    // if(a < b)
    // {
    //     a = b;
    // }
    // else if(1+3)
    // {
    //     2 + 3;
    // }
    // else
    // {
    //     if(a && b)
    //     {
    //         2+4;
    //     }
    //     else if(a + b);
    //     else;

    // }
    

    // while(a <= b)
    // {

    //     if(a >= c)
    //     {
    //         while(1)
    //         {

    //         }
    //     }

    // }

    // for(1;1;1)
    // {
    //     1;
    // }
    
    // for(;;);


}